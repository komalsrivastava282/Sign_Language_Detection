# My First Project > 2025-06-24 2:13pm
https://universe.roboflow.com/vidhi-sharma-yasco/my-first-project-cac9q

Provided by a Roboflow user
License: CC BY 4.0

